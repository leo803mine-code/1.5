package dev.flr.visuals;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class FlrSounds {
    private static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, FlrVisuals.MOD_ID);
    public static final DeferredHolder<SoundEvent, SoundEvent> TRACK = SOUNDS.register("flr_track",
            () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(FlrVisuals.MOD_ID, "flr_track")));

    public static void register(IEventBus bus) {
        SOUNDS.register(bus);
    }
}
