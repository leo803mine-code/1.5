package dev.flr.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWGamepadState;

/**
 * Поддержка геймпада через GLFW (Minecraft уже использует LWJGL).
 * Опрос идёт раз в клиентский тик, см. {@link GameEvents#tick}.
 *
 * В игре:   Back = меню, L3+R3 = вкл/выкл FLR, LB+RB = трек.
 * В меню:   D-pad / левый стик = навигация и изменение значений,
 *           A = выбрать, X = настройки пункта, B = назад/закрыть,
 *           LB/RB = вкладки, правый стик = прокрутка.
 */
public final class Gamepad {
    private static final float DEAD = 0.25f;
    private static final float PRESS = 0.55f;
    private static final int FIRST_DELAY = 10, REPEAT = 3;

    private static final boolean[] prev = new boolean[GLFW.GLFW_GAMEPAD_BUTTON_LAST + 1];
    private static final int[] hold = new int[4]; // 0 вверх, 1 вниз, 2 влево, 3 вправо
    private static boolean combo;

    private Gamepad() {}

    private static int findPad() {
        for (int id = GLFW.GLFW_JOYSTICK_1; id <= GLFW.GLFW_JOYSTICK_LAST; id++) {
            if (GLFW.glfwJoystickIsGamepad(id)) return id;
        }
        return -1;
    }

    private static float dead(float v) {
        return Math.abs(v) < DEAD ? 0f : v;
    }

    public static void tick(Minecraft mc) {
        if (!Config.gamepad || !mc.isWindowActive()) return;
        int id = findPad();
        if (id < 0) return;
        GLFWGamepadState st = GLFWGamepadState.create();
        if (!GLFW.glfwGetGamepadState(id, st)) return;

        boolean[] now = new boolean[prev.length];
        for (int i = 0; i < now.length; i++) now[i] = st.buttons(i) == GLFW.GLFW_PRESS;

        float lx = dead(st.axes(GLFW.GLFW_GAMEPAD_AXIS_LEFT_X));
        float ly = dead(st.axes(GLFW.GLFW_GAMEPAD_AXIS_LEFT_Y));
        float ry = dead(st.axes(GLFW.GLFW_GAMEPAD_AXIS_RIGHT_Y));

        boolean[] dir = {
                now[GLFW.GLFW_GAMEPAD_BUTTON_DPAD_UP] || ly < -PRESS,
                now[GLFW.GLFW_GAMEPAD_BUTTON_DPAD_DOWN] || ly > PRESS,
                now[GLFW.GLFW_GAMEPAD_BUTTON_DPAD_LEFT] || lx < -PRESS,
                now[GLFW.GLFW_GAMEPAD_BUTTON_DPAD_RIGHT] || lx > PRESS
        };

        if (mc.screen instanceof CosmeticsScreen cs) {
            menu(cs, now, dir, ry);
        } else if (mc.screen == null && mc.player != null) {
            ingame(mc, now);
        } else {
            for (int i = 0; i < hold.length; i++) hold[i] = 0;
        }
        System.arraycopy(now, 0, prev, 0, now.length);
    }

    private static boolean pressed(boolean[] now, int b) {
        return now[b] && !prev[b];
    }

    private static void ingame(Minecraft mc, boolean[] now) {
        int back = GLFW.GLFW_GAMEPAD_BUTTON_BACK;
        int l3 = GLFW.GLFW_GAMEPAD_BUTTON_LEFT_THUMB, r3 = GLFW.GLFW_GAMEPAD_BUTTON_RIGHT_THUMB;
        int lb = GLFW.GLFW_GAMEPAD_BUTTON_LEFT_BUMPER, rb = GLFW.GLFW_GAMEPAD_BUTTON_RIGHT_BUMPER;

        if (now[l3] && now[r3] && (pressed(now, l3) || pressed(now, r3))) {
            Config.master = !Config.master;
            Config.save();
            mc.player.displayClientMessage(Component.literal(Tr.fmt("FLR Visuals: %s", Tr.tr(Config.master ? "ON" : "OFF"))), true);
            return;
        }
        if (now[lb] && now[rb] && (pressed(now, lb) || pressed(now, rb))) {
            mc.getSoundManager().play(SimpleSoundInstance.forUI(FlrSounds.TRACK, 1.0f));
            return;
        }
        if (pressed(now, back)) mc.setScreen(new CosmeticsScreen());
    }

    private static void menu(CosmeticsScreen cs, boolean[] now, boolean[] dir, float ry) {
        // повтор при удержании: сразу, затем через FIRST_DELAY, затем каждые REPEAT тиков
        for (int i = 0; i < 4; i++) {
            if (!dir[i]) { hold[i] = 0; continue; }
            boolean fire = hold[i] == 0 || (hold[i] >= FIRST_DELAY && (hold[i] - FIRST_DELAY) % REPEAT == 0);
            hold[i]++;
            if (!fire) continue;
            switch (i) {
                case 0 -> cs.padMove(-1);
                case 1 -> cs.padMove(1);
                case 2 -> cs.padAdjust(-1);
                default -> cs.padAdjust(1);
            }
        }
        if (ry != 0f) cs.padScroll(ry * 14f);

        if (pressed(now, GLFW.GLFW_GAMEPAD_BUTTON_A)) cs.padActivate();
        if (pressed(now, GLFW.GLFW_GAMEPAD_BUTTON_X)) cs.padSub();
        if (pressed(now, GLFW.GLFW_GAMEPAD_BUTTON_B)) cs.padBack();
        if (pressed(now, GLFW.GLFW_GAMEPAD_BUTTON_LEFT_BUMPER)) cs.padTab(-1);
        if (pressed(now, GLFW.GLFW_GAMEPAD_BUTTON_RIGHT_BUMPER)) cs.padTab(1);
        if (pressed(now, GLFW.GLFW_GAMEPAD_BUTTON_BACK)) cs.onClose();
    }
}
